// Объект с переводами
const translations = {
    ru: {
        home: "Главная",
        estimate: "Смета",
        contacts: "Контакты",
        login: "Вход",
        register: "Регистрация",
        hero_title: "Добро пожаловать в MsMeta",
        hero_text: "MsMeta — это гарантия профессионального подхода, высокой точности расчетов и надежности в работе с документацией. Мы помогаем нашим клиентам экономить время и минимизировать риски.",
        create_estimate: "Создать смету",
        advantages_title: "Наши преимущества",
        quality: "Качество",
        quality_text: "Мы предоставляем только высококачественные услуги, удовлетворяя все требования клиентов.",
        flexibility: "Гибкость",
        flexibility_text: "Мы адаптируем наши решения под уникальные нужды каждого клиента.",
        speed: "Скорость",
        speed_text: "Выполняем работы в срок, не нарушая стандартов качества.",
        support: "Поддержка",
        support_text: "Готовы помочь и предоставить поддержку на всех этапах сотрудничества.",
        innovation: "Инновации",
        innovation_text: "Мы внедряем современные технологии для повышения эффективности работы.",
        security: "Безопасность",
        security_text: "Ваши данные и документы надежно защищены."
    },
    ro: {
        home: "Acasă",
        estimate: "Estimare",
        contacts: "Contacte",
        login: "Autentificare",
        register: "Înregistrare",
        hero_title: "Bine ați venit la MsMeta",
        hero_text: "MsMeta este garanția unei abordări profesionale, a unui calcul precis și a fiabilității în gestionarea documentației. Ajutăm clienții noștri să economisească timp și să reducă riscurile.",
        create_estimate: "Creați o estimare",
        advantages_title: "Avantajele noastre",
        quality: "Calitate",
        quality_text: "Oferim doar servicii de înaltă calitate, respectând toate cerințele clienților.",
        flexibility: "Flexibilitate",
        flexibility_text: "Adaptăm soluțiile noastre la nevoile unice ale fiecărui client.",
        speed: "Viteză",
        speed_text: "Finalizăm lucrările la timp, fără a compromite calitatea.",
        support: "Suport",
        support_text: "Suntem gata să oferim ajutor și suport la toate etapele colaborării.",
        innovation: "Inovație",
        innovation_text: "Implementăm tehnologii moderne pentru a crește eficiența muncii.",
        security: "Securitate",
        security_text: "Datele și documentele dvs. sunt protejate în siguranță."
    }
};

// Функция смены языка
function changeLanguage(lang) {
    localStorage.setItem("selectedLanguage", lang);
    applyLanguage(lang);
}

// Функция применения перевода ко всем элементам
function applyLanguage(lang) {
    document.querySelector('[data-lang="home"]').textContent = translations[lang].home;
    document.querySelector('[data-lang="estimate"]').textContent = translations[lang].estimate;
    document.querySelector('[data-lang="contacts"]').textContent = translations[lang].contacts;
    document.querySelector('[data-lang="login"]').textContent = translations[lang].login;
    document.querySelector('[data-lang="register"]').textContent = translations[lang].register;

    document.querySelector("#hero h1").textContent = translations[lang].hero_title;
    document.querySelector("#hero p").textContent = translations[lang].hero_text;
    document.querySelector("#hero a").textContent = translations[lang].create_estimate;

    document.querySelector("#advantages h2").textContent = translations[lang].advantages_title;
    
    const advantageItems = document.querySelectorAll(".advantage");
    advantageItems[0].querySelector("h3").textContent = translations[lang].quality;
    advantageItems[0].querySelector("p").textContent = translations[lang].quality_text;

    advantageItems[1].querySelector("h3").textContent = translations[lang].flexibility;
    advantageItems[1].querySelector("p").textContent = translations[lang].flexibility_text;

    advantageItems[2].querySelector("h3").textContent = translations[lang].speed;
    advantageItems[2].querySelector("p").textContent = translations[lang].speed_text;

    advantageItems[3].querySelector("h3").textContent = translations[lang].support;
    advantageItems[3].querySelector("p").textContent = translations[lang].support_text;

    advantageItems[4].querySelector("h3").textContent = translations[lang].innovation;
    advantageItems[4].querySelector("p").textContent = translations[lang].innovation_text;

    advantageItems[5].querySelector("h3").textContent = translations[lang].security;
    advantageItems[5].querySelector("p").textContent = translations[lang].security_text;
}

// Применяем язык при загрузке страницы
document.addEventListener("DOMContentLoaded", function () {
    const savedLanguage = localStorage.getItem("selectedLanguage") || "ru";
    applyLanguage(savedLanguage);
});
document.addEventListener("DOMContentLoaded", function () {
    const cards = document.querySelectorAll(".advantage");

    function revealCards() {
        cards.forEach((card, index) => {
            if (card.getBoundingClientRect().top < window.innerHeight - 50) {
                card.style.opacity = "1";
                card.style.transform = "translateY(0)";
            }
        });
    }

    window.addEventListener("scroll", revealCards);
    revealCards(); // Вызываем сразу для проверки
});
document.addEventListener("DOMContentLoaded", function () {
    const advantagesSection = document.getElementById("advantages");
    advantagesSection.style.backgroundImage = "url('img/background2.jpg')"; // Поменяй на свою картинку
});
