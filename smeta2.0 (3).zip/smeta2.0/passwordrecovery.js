// Обрабатываем форму для ввода email
document.getElementById("resetForm").addEventListener("submit", function(event) {
    event.preventDefault();  // Предотвращаем отправку формы

    const email = document.getElementById("email").value;  // Получаем email пользователя

    if (email.trim() === "") {
        alert("Пожалуйста, введите ваш email!");
        return;
    }

    // Генерация случайного кода восстановления
    const recoveryCode = Math.floor(100000 + Math.random() * 900000);  // Генерация 6-значного кода
    console.log("Отправка кода на email:", email);
    alert(`Инструкция по восстановлению пароля отправлена на ваш email. Ваш код: ${recoveryCode}`);

    // Переключаем формы: скрываем форму ввода email и показываем форму для ввода кода
    document.getElementById("resetForm").style.display = "none";
    document.getElementById("codeForm").style.display = "block";

    // Сохраняем код в localStorage (для имитации)
    localStorage.setItem("recoveryCode", recoveryCode);
});

// Проверка кода при вводе
document.getElementById("confirmCode").addEventListener("click", function() {
    const enteredCode = document.getElementById("confirmationCode").value;  // Введённый код
    const storedCode = localStorage.getItem("recoveryCode");  // Сохранённый код

    if (enteredCode === storedCode) {
        alert("Код подтверждён! Переходите к восстановлению пароля.");
        window.location.href = "reset-password.html";  // Перенаправление на страницу ввода нового пароля
    } else {
        alert("Неверный код! Пожалуйста, попробуйте снова.");
    }
});
