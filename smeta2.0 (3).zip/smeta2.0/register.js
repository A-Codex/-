// Функция смены языка и сохранения в localStorage
function changeLanguage(lang) {
    document.documentElement.lang = lang;
    localStorage.setItem('lang', lang);  // Сохраняем выбранный язык
    const elements = document.querySelectorAll('[data-lang]');
    elements.forEach(el => {
        el.textContent = translations[lang][el.dataset.lang];
    });

    // Меняем placeholder'ы для input'ов
    document.getElementById('name').placeholder = translations[lang].name;
    document.getElementById('email').placeholder = translations[lang].email;
    document.getElementById('telephone').placeholder = translations[lang].telephone;
    document.getElementById('company').placeholder = translations[lang].company;
    document.getElementById('password').placeholder = translations[lang].password;
}

const translations = {
    ru: {
        register: "Регистрация",
        name: "Имя и Фамилия",
        email: "Email",
        telephone: "Тел",
        company: "Название компании",
        password: "Пароль",
        registerBtn: "Зарегистрироваться",
        login: "Войти",
        alreadyHaveAccount: "Уже есть аккаунт?"
    },
    ro: {
        register: "Înregistrare",
        name: "Nume și Prenume",
        email: "Email",
        telephone: "Telefon",
        company: "Numele companiei",
        password: "Parola",
        registerBtn: "Înregistrează-te",
        login: "Autentificare",
        alreadyHaveAccount: "Ai deja un cont?"
    }
};

// Проверяем выбранный язык при загрузке страницы
window.onload = function () {
    const lang = localStorage.getItem('lang') || 'ru'; // Получаем язык из localStorage
    changeLanguage(lang); // Применяем язык

    // Обрабатываем отправку формы регистрации
    document.getElementById('registerForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Предотвращаем стандартное поведение формы
        alert(translations[lang].register + " успешно!"); // Показываем сообщение
        window.location.href = 'login.html'; // Перенаправляем на страницу входа
    });
};
