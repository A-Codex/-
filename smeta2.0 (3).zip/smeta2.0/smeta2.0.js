document.getElementById('addItem').addEventListener('click', addItem);
document.getElementById('generatePDF').addEventListener('click', generatePDF);

function addItem() {
    const table = document.getElementById('itemsTable').getElementsByTagName('tbody')[0];
    const newRow = table.insertRow();

    newRow.innerHTML = `
        <td><input type="text" class="itemDesc" placeholder="Описание"></td>
        <td><input type="number" class="itemQty" placeholder="Количество"></td>
        <td><input type="number" class="itemPrice" placeholder="Цена"></td>
        <td><input type="number" class="itemTotal" readonly></td>
        <td><button class="removeItem">Удалить</button></td>
    `;
    newRow.querySelector('.removeItem').addEventListener('click', removeItem);
    updateTotals();
}

function removeItem(event) {
    const row = event.target.closest('tr');
    row.remove();
    updateTotals();
}

function updateTotals() {
    let totalAmount = 0;
    const rows = document.querySelectorAll('#itemsTable tbody tr');

    rows.forEach(row => {
        const qty = row.querySelector('.itemQty').value || 0;
        const price = row.querySelector('.itemPrice').value || 0;
        const total = qty * price;
        row.querySelector('.itemTotal').value = total;
        totalAmount += total;
    });

    document.getElementById('totalAmount').textContent = totalAmount.toFixed(2);
}

function generatePDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Используем встроенный шрифт Helvetica, который поддерживает кириллицу
    doc.setFont('helvetica');  // Устанавливаем шрифт Helvetica, поддерживающий кириллицу
    doc.setFontSize(16);
    doc.text('Смета', 10, 10);

    doc.setFontSize(12);
    doc.text(`Компания: ${document.getElementById('companyName').value}`, 10, 20);
    doc.text(`Клиент: ${document.getElementById('clientName').value}`, 10, 30);
    doc.text(`Проект: ${document.getElementById('projectTitle').value}`, 10, 40);
    doc.text(`Дата: ${document.getElementById('projectDate').value}`, 10, 50);

    const rows = document.querySelectorAll('#itemsTable tbody tr');
    let yOffset = 60;
    rows.forEach(row => {
        const desc = row.querySelector('.itemDesc').value;
        const qty = row.querySelector('.itemQty').value;
        const price = row.querySelector('.itemPrice').value;
        const total = row.querySelector('.itemTotal').value;

        doc.text(`${desc} - ${qty} x ${price} = ${total}`, 10, yOffset);
        yOffset += 10;
    });

    doc.text(`Итого: ${document.getElementById('totalAmount').textContent} руб.`, 10, yOffset);

    doc.save('estimate.pdf');
}
