document.getElementById("newPasswordForm").addEventListener("submit", function(event) {
    event.preventDefault();  // Предотвращаем стандартное поведение формы

    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
        alert("Пароли не совпадают! Пожалуйста, попробуйте снова.");
        return;
    }

    alert("Ваш новый пароль успешно сохранён!");
    window.location.href = "login.html";  // Перенаправление на страницу входа
});
