// Словарь с переводами
const translations = {
    ru: {
        home: "Главная",
        myEstimate: "Моя Смета",
        contracts: "Контракты",
        logout: "Выход"
    },
    ro: {
        home: "Acasă",
        myEstimate: "Estimarea mea",
        contracts: "Contracte",
        logout: "Ieșire"
    }
};

// Функция для смены языка
function changeLanguage(language) {
    const elements = document.querySelectorAll('[data-lang]');
    elements.forEach(el => {
        const key = el.getAttribute('data-lang');
        if (translations[language] && translations[language][key]) {
            el.innerHTML = translations[language][key];
        }
    });
}

// Слушатель события на кнопки для смены языка
document.addEventListener('DOMContentLoaded', () => {
    // Устанавливаем язык по умолчанию (русский)
    changeLanguage('ru');
    
    // Обработчик событий для кнопок переключения языка
    const buttons = document.querySelectorAll('.lang-switcher button');
    buttons.forEach(button => {
        button.addEventListener('click', (event) => {
            const lang = event.target.getAttribute('onclick').match(/'(.*)'/)[1];
            changeLanguage(lang);
        });
    });
});
