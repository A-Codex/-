// Функция смены языка и сохранения в localStorage
function changeLanguage(lang) {
    document.documentElement.lang = lang;
    localStorage.setItem('lang', lang);  // Сохраняем выбранный язык
    const elements = document.querySelectorAll('[data-lang]');
    elements.forEach(el => {
        el.textContent = translations[lang][el.dataset.lang];
    });

    // Меняем placeholder'ы для input'ов вручную
    document.getElementById('emailOrPhone').setAttribute('placeholder', translations[lang].emailOrPhone);
    document.getElementById('password').setAttribute('placeholder', translations[lang].password);
}

const translations = {
    ru: {
        login: "Вход",
        emailOrPhone: "Email или Телефон",
        password: "Пароль",
        loginBtn: "Войти",
        register: "Зарегистрироваться",
        forgotPassword: "Забыли пароль?"
    },
    ro: {
        login: "Autentificare",
        emailOrPhone: "Email sau Telefon",
        password: "Parola",
        loginBtn: "Intră",
        register: "Înregistrare",
        forgotPassword: "Ai uitat parola?"
    }
};

// Проверяем выбранный язык при загрузке страницы
window.onload = function () {
    const lang = localStorage.getItem('lang') || 'ru'; // Получаем язык из localStorage
    changeLanguage(lang); // Применяем язык

    // Обрабатываем отправку формы входа
    document.getElementById('loginForm').addEventListener('submit', function (event) {
        event.preventDefault(); // Предотвращаем стандартное поведение формы
        window.location.href = 'indexprivat.html'; // Перенаправляем на новую страницу
    });
};
