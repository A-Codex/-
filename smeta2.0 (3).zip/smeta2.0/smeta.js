document.addEventListener("DOMContentLoaded", function () {
    initDropdowns();
    initVatButtons();
    initCurrencySwitcher();
    initRowEvents();

    document.getElementById("addRow").addEventListener("click", function () {
        let newRow = document.querySelector("#invoiceBody tr").cloneNode(true);

        // Очистка значений новой строки
        newRow.querySelector(".quantity").value = 1;
        newRow.querySelector(".price").value = 1000;
        newRow.querySelector(".vat-percentage").value = 20;
        newRow.querySelector(".total").textContent = "1000";

        // Применение валюты к новой строке
        applyCurrencyToRow(newRow);

        // Привязываем события к новой строке
        setupRowEvents(newRow);

        document.getElementById("invoiceBody").appendChild(newRow);
        calculateTotal(); // Пересчитываем общую сумму
    });

    document.getElementById("removeRow").addEventListener("click", function () {
        let rows = document.querySelectorAll("#invoiceBody tr");
        if (rows.length > 1) {
            rows[rows.length - 1].remove();
            calculateTotal(); // Пересчитываем общую сумму после удаления
        } else {
            alert("Должна остаться хотя бы одна строка!");
        }
    });

    // Кнопка для скачивания PDF
    document.getElementById("downloadPDF").addEventListener("click", function () {
        downloadPDF();
    });
});

// === ИНИЦИАЛИЗАЦИЯ СИСТЕМ ===

// Выпадающий список наименований
function initDropdowns() {
    document.querySelectorAll(".dropdown-btn").forEach(button => {
        button.onclick = function () {
            let dropdown = this.nextElementSibling;
            dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
        };
    });

    document.querySelectorAll(".dropdown-list li").forEach(item => {
        item.onclick = function () {
            let inputField = this.closest(".dropdown").querySelector(".item-name");
            inputField.value = this.textContent;
            this.parentElement.style.display = "none";
        };
    });
}

// Кнопка "✔" для включения НДС
function initVatButtons() {
    document.querySelectorAll(".vat-toggle").forEach(button => {
        button.onclick = function () {
            let row = this.closest("tr");
            let vatInput = row.querySelector(".vat-percentage");

            if (this.classList.contains("inactive")) {
                this.classList.remove("inactive");
                vatInput.dataset.enabled = "true";
            } else {
                this.classList.add("inactive");
                vatInput.dataset.enabled = "false";
            }
            calculateTotal(); // Пересчитываем общую сумму
        };
    });
}

// Переключение валюты
function initCurrencySwitcher() {
    document.getElementById("currencySelect").addEventListener("change", function () {
        applyCurrencyToAllRows();
        calculateTotal(); // Пересчитываем общую сумму
    });
}

// Добавление событий к каждой строке
function initRowEvents() {
    document.querySelectorAll("#invoiceBody tr").forEach(row => {
        setupRowEvents(row);
    });
}

// === ФУНКЦИИ ===

// Применение валюты ко всем строкам
function applyCurrencyToAllRows() {
    document.querySelectorAll("#invoiceBody tr").forEach(row => {
        applyCurrencyToRow(row);
    });
}

// Применение валюты к конкретной строке
function applyCurrencyToRow(row) {
    let selectedCurrency = document.getElementById("currencySelect").value;
    row.querySelector(".total").dataset.currency = selectedCurrency;
}

// Пересчёт общей суммы
function calculateTotal() {
    let total = 0;
    let selectedCurrency = document.getElementById("currencySelect").value;

    document.querySelectorAll("#invoiceBody tr").forEach(row => {
        let quantity = row.querySelector(".quantity").value;
        let price = row.querySelector(".price").value;
        let vatInput = row.querySelector(".vat-percentage");
        let vatEnabled = vatInput.dataset.enabled === "true";
        let vat = vatEnabled ? parseFloat(vatInput.value) : 0;
        let rowTotal = quantity * price;

        if (vatEnabled) {
            rowTotal += rowTotal * (vat / 100);
        }

        let totalCell = row.querySelector(".total");
        totalCell.textContent = rowTotal.toFixed(2) + " " + selectedCurrency;
        totalCell.style.minWidth = "120px"; // Увеличили ширину итогов
        total += rowTotal;
    });

    let grandTotalCell = document.getElementById("grandTotal");
    grandTotalCell.textContent = total.toFixed(2) + " " + selectedCurrency;
    grandTotalCell.style.minWidth = "120px"; // Увеличили ширину итоговой суммы
}

// Настройка событий для новой строки
function setupRowEvents(row) {
    // Выпадающий список
    let dropdownBtn = row.querySelector(".dropdown-btn");
    let dropdownList = row.querySelector(".dropdown-list");
    let itemNameInput = row.querySelector(".item-name");

    dropdownBtn.onclick = function () {
        dropdownList.style.display = dropdownList.style.display === "block" ? "none" : "block";
    };

    dropdownList.querySelectorAll("li").forEach(item => {
        item.onclick = function () {
            itemNameInput.value = this.textContent;
            dropdownList.style.display = "none";
        };
    });

    // Кнопка НДС "✔"
    let vatToggle = row.querySelector(".vat-toggle");
    let vatInput = row.querySelector(".vat-percentage");

    vatToggle.onclick = function () {
        if (vatToggle.classList.contains("inactive")) {
            vatToggle.classList.remove("inactive");
            vatInput.dataset.enabled = "true";
        } else {
            vatToggle.classList.add("inactive");
            vatInput.dataset.enabled = "false";
        }
        calculateTotal(); // Пересчитываем общую сумму
    };

    // Удаление строки
    row.querySelector(".remove-row").addEventListener("click", function () {
        if (document.querySelectorAll("#invoiceBody tr").length > 1) {
            row.remove();
            calculateTotal(); // Пересчитываем общую сумму после удаления
        } else {
            alert("Должна остаться хотя бы одна строка!");
        }
    });

    // Обновление расчёта при изменении значений
    row.querySelectorAll("input, select").forEach(input => {
        input.addEventListener("input", calculateTotal);
    });
}

// === Генерация PDF с кириллицей ===

function downloadPDF() {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Base64 строка для шрифта Roboto
    const robotoBase64 = "AAEAAAARAQAAAAAAAAA...";

    // Добавляем шрифт в pdf
    doc.addFileToVFS("Roboto-Regular.ttf", robotoBase64);
    doc.addFont("Roboto-Regular.ttf", "Roboto", "normal");
    doc.setFont("Roboto");  // Устанавливаем шрифт

    doc.setFontSize(16);

    // Заголовок документа
    doc.text("Смета на проект", 14, 20);

    // Таблица с данными
    let y = 30; // Начальная высота для таблицы

    // Заголовки таблицы
    doc.setFontSize(12);
    doc.text("№", 14, y);
    doc.text("Наименование", 30, y);
    doc.text("Кол-во", 70, y);
    doc.text("Ед. изм.", 90, y);
    doc.text("Цена за ед.", 110, y);
    doc.text("НДС", 150, y);
    doc.text("Итого", 170, y);

    y += 10; // Отступ после заголовков

    // Данные строк таблицы
    document.querySelectorAll("#invoiceBody tr").forEach((row, index) => {
        doc.text((index + 1).toString(), 14, y);
        doc.text(row.querySelector(".item-name").value, 30, y);
        doc.text(row.querySelector(".quantity").value, 70, y);
        doc.text(row.querySelector(".unit").value, 90, y);
        doc.text(row.querySelector(".price").value, 110, y);
        doc.text(row.querySelector(".vat-percentage").value, 150, y);
        doc.text(row.querySelector(".total").textContent, 170, y);

        y += 10; // Отступ после каждой строки
    });

    // Итого
    doc.setFontSize(14);
    doc.text("Итого: " + document.getElementById("grandTotal").textContent, 14, y + 10);

    // Скачивание PDF
    doc.save("smeta.pdf");
}
