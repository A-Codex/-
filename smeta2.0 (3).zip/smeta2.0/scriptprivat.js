// Функция для смены языка
function changeLanguage(lang) {
    // Сохраняем выбранный язык в localStorage
    localStorage.setItem('language', lang);
    location.reload();  // Перезагружаем страницу, чтобы применить изменения
}

// Автоматически загружаем язык при загрузке страницы
window.addEventListener('load', function() {
    const lang = localStorage.getItem('language') || 'ru';  // Если язык не выбран, по умолчанию - RU
    translatePage(lang);
});

// Функция для перевода страницы в зависимости от выбранного языка
function translatePage(lang) {
    const elements = document.querySelectorAll('[data-lang]');
    
    const translations = {
        'ru': {
            'home': 'Главная',
            'myEstimate': 'Моя Смета',
            'contracts': 'Контракты',
            'logout': 'Выход'
        },
        'ro': {
            'home': 'Acasă',
            'myEstimate': 'Estimarea mea',
            'contracts': 'Contracte',
            'logout': 'Ieșire'
        }
    };

    // Применяем перевод к элементам
    elements.forEach(element => {
        const key = element.getAttribute('data-lang');
        if (translations[lang] && translations[lang][key]) {
            element.textContent = translations[lang][key];
        }
    });
}
// Функция для открытия/закрытия боковой панели
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    
    sidebar.classList.toggle('active');
    sidebarToggle.classList.toggle('active'); // Меняем стиль кнопки при открытии панели
    sidebarToggle.classList.toggle('hidden'); // Скрываем бургер-меню при открытой панели
}

// Функция для смены языка (временно)
function changeLanguage(lang) {
    console.log("Switching to language:", lang);
}
